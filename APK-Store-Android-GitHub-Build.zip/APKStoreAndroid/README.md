# APK Store Android (project source)

Aplikasi Android native sederhana dengan katalog, pencarian, kategori, rekomendasi, aplikasi terbaru/populer, halaman detail, dan tombol menuju halaman unduhan resmi pengembang.

## Cara membuka dan membangun
1. Instal Android Studio pada komputer.
2. Ekstrak ZIP ini.
3. Android Studio → Open → pilih folder `APKStoreAndroid`.
4. Tunggu Gradle Sync selesai, lalu tekan Run untuk menjalankan di emulator/HP Android.
5. Untuk membuat APK: Build → Build APK(s). APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Penting tentang unduhan
Aplikasi sengaja mengarahkan pengguna ke halaman resmi pengembang. Tidak semua pengembang menyediakan URL APK langsung yang stabil; beberapa hanya menyediakan Google Play atau mengubah URL versi. Dengan membuka halaman resmi, pengguna mendapatkan petunjuk dan file yang disediakan pengembang. Aplikasi ini tidak meng-host APK dan tidak mengklaim ukuran/versi live; label tersebut ditandai sebagai bervariasi.

## Katalog
Katalog contoh dapat diedit di `MainActivity.kt` pada daftar `apps`. Tambahkan item dengan nama, kategori, deskripsi, rating tampilan, emoji, dan URL resmi pengembang.

## Batasan versi awal
- Data katalog masih contoh statis, belum terhubung API.
- Rating/daftar terbaru/populer adalah contoh UI, bukan data live.
- Tidak mengunduh APK secara diam-diam di dalam aplikasi; tombol membuka sumber resmi untuk mengikuti mekanisme unduhan pengembang.

## Build otomatis lewat GitHub dari HP
1. Buat repository baru di https://github.com/new (nama contoh: APKStoreAndroid).
2. Upload seluruh isi folder project ZIP ini ke repository, termasuk folder tersembunyi `.github/workflows/android.yml`.
3. Buka tab **Actions** di repository. Jika workflow belum jalan otomatis, pilih **Build APK STORE** lalu **Run workflow**.
4. Tunggu job selesai berstatus hijau.
5. Buka run yang selesai, gulir ke **Artifacts**, lalu unduh `APK-STORE-debug`.
6. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`, lalu pasang di HP.
