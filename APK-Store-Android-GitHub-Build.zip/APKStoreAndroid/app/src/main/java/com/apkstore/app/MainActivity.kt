package com.apkstore.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher

data class AppInfo(
    val name: String, val category: String, val developer: String,
    val description: String, val version: String, val size: String,
    val rating: String, val emoji: String, val officialUrl: String
)

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 17, 29)
    private val panel = Color.rgb(20, 36, 53)
    private val blue = Color.rgb(22, 139, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(174, 193, 211)
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private var selectedCategory = "Semua"
    private var query = ""

    // Official developer/download pages. The developer's site controls the actual APK availability.
    private val apps = listOf(
        AppInfo("F-Droid", "Alat", "F-Droid", "Katalog aplikasi Android gratis dan open-source. Halaman resmi menyediakan unduhan APK dan informasi verifikasi.", "Terbaru di situs resmi", "Bervariasi", "4.6", "🟦", "https://f-droid.org/"),
        AppInfo("Telegram", "Sosial", "Telegram", "Aplikasi pesan dengan sinkronisasi cloud, grup, kanal, dan berbagi file. Gunakan halaman resmi untuk versi Android.", "Terbaru di situs resmi", "Bervariasi", "4.5", "✈️", "https://telegram.org/android"),
        AppInfo("Firefox", "Produktivitas", "Mozilla", "Peramban web dengan perlindungan privasi, sinkronisasi, dan dukungan ekstensi tertentu di Android.", "Terbaru di situs resmi", "Bervariasi", "4.4", "🦊", "https://www.mozilla.org/firefox/android/"),
        AppInfo("VLC", "Hiburan", "VideoLAN", "Pemutar media gratis dan open-source untuk berbagai format video dan audio.", "Terbaru di situs resmi", "Bervariasi", "4.4", "▶️", "https://www.videolan.org/vlc/download-android.html"),
        AppInfo("Signal", "Sosial", "Signal Foundation", "Aplikasi komunikasi yang berfokus pada privasi dengan pesan dan panggilan terenkripsi.", "Terbaru di situs resmi", "Bervariasi", "4.4", "💬", "https://signal.org/android/apk/"),
        AppInfo("KDE Connect", "Produktivitas", "KDE", "Menghubungkan perangkat Android dengan komputer untuk berbagi berkas dan fitur lintas perangkat.", "Terbaru di situs resmi", "Bervariasi", "4.3", "🔗", "https://kdeconnect.kde.org/"),
        AppInfo("Proton VPN", "Alat", "Proton", "Layanan VPN dengan aplikasi Android resmi. Periksa detail, negara layanan, dan ketentuan di situs pengembang.", "Terbaru di situs resmi", "Bervariasi", "4.2", "🛡️", "https://protonvpn.com/download-android"),
        AppInfo("Wikipedia", "Pendidikan", "Wikimedia Foundation", "Akses ensiklopedia Wikipedia dan membaca artikel dalam berbagai bahasa.", "Terbaru di situs resmi", "Bervariasi", "4.5", "📚", "https://www.wikipedia.org/"),
        AppInfo("Organic Maps", "Alat", "Organic Maps", "Peta offline untuk navigasi dan perjalanan, berfokus pada privasi dan data OpenStreetMap.", "Terbaru di situs resmi", "Bervariasi", "4.5", "🗺️", "https://organicmaps.app/")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
    }

    private fun base(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val header = TextView(this).apply {
            text = "▶  $title"
            textSize = 24f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(14))
        }
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun renderHome() {
        base("APK Store")
        val subtitle = TextView(this).apply {
            text = "Temukan aplikasi dari sumber resmi pengembang"
            textSize = 14f; setTextColor(muted); setPadding(0, 0, 0, dp(14))
        }
        content.addView(subtitle)
        search = EditText(this).apply {
            hint = "Cari aplikasi, game, atau developer..."
            setHintTextColor(muted); setTextColor(white); textSize = 15f
            setSingleLine(true); setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(panel)
        }
        content.addView(search, matchWrap())
        val categories = listOf("Semua", "Game", "Sosial", "Produktivitas", "Hiburan", "Alat", "Pendidikan")
        val catScroll = HorizontalScrollView(this)
        val catRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(12)) }
        categories.forEach { cat ->
            val b = Button(this).apply {
                text = cat; textSize = 11f; isAllCaps = false
                setTextColor(white); setBackgroundColor(if (cat == selectedCategory) blue else panel)
                setOnClickListener { selectedCategory = cat; renderList() }
            }
            catRow.addView(b, LinearLayout.LayoutParams(-2, dp(42)).apply { rightMargin = dp(6) })
        }
        catScroll.addView(catRow)
        content.addView(catScroll)
        addSection("Rekomendasi untuk kamu", apps.take(4))
        addSection("Aplikasi terbaru", apps.reversed().take(4))
        addSection("Aplikasi populer", apps.sortedByDescending { it.rating.toFloatOrNull() ?: 0f }.take(5))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString()?.trim().orEmpty(); renderList() }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun renderList() {
        // Keep the search field and category strip; update app lists below them.
        while (content.childCount > 3) content.removeViewAt(content.childCount - 1)
        val filtered = apps.filter {
            (selectedCategory == "Semua" || it.category == selectedCategory) &&
            (query.isBlank() || it.name.contains(query, true) || it.developer.contains(query, true) || it.category.contains(query, true))
        }
        addSection(if (query.isBlank()) "Aplikasi" else "Hasil pencarian", filtered)
        if (filtered.isEmpty()) content.addView(label("Tidak ada hasil. Coba kata kunci lain.", muted, 14f))
    }

    private fun addSection(title: String, items: List<AppInfo>) {
        content.addView(label(title, white, 18f, true).apply { setPadding(0, dp(12), 0, dp(8)) })
        items.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(panel)
            }
            val icon = TextView(this).apply { text = app.emoji; textSize = 28f; gravity = Gravity.CENTER }
            row.addView(icon, LinearLayout.LayoutParams(dp(52), dp(52)))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(6), 0) }
            details.addView(label(app.name, white, 16f, true))
            details.addView(label("${app.category} • ${app.developer}", muted, 12f))
            details.addView(label("★ ${app.rating}  •  ${app.size}", muted, 12f))
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val button = Button(this).apply {
                text = "Detail"; textSize = 11f; isAllCaps = false; setTextColor(white); setBackgroundColor(blue)
                setOnClickListener { showDetail(app) }
            }
            row.addView(button)
            row.setOnClickListener { showDetail(app) }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8)
            content.addView(row, lp)
        }
    }

    private fun showDetail(app: AppInfo) {
        base(app.name)
        content.addView(label("${app.emoji}  ${app.name}", white, 23f, true))
        content.addView(label("${app.developer} • ${app.category}", muted, 14f).apply { setPadding(0, dp(8), 0, dp(12)) })
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(16)) }
        listOf("★ ${app.rating}\nRating", app.size + "\nUkuran", app.version + "\nVersi").forEach {
            stats.addView(label(it, white, 12f).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(panel) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(5) })
        }
        content.addView(stats)
        content.addView(label("Tentang aplikasi", white, 18f, true).apply { setPadding(0, dp(8), 0, dp(8)) })
        content.addView(label(app.description, muted, 15f).apply { setPadding(0, 0, 0, dp(18)) })
        content.addView(label("Sumber unduhan resmi", white, 17f, true))
        content.addView(label("Tombol di bawah membuka halaman resmi pengembang. Ketersediaan file APK dan cara unduh mengikuti situs pengembang.", muted, 13f).apply { setPadding(0, dp(8), 0, dp(16)) })
        val download = Button(this).apply {
            text = "Buka unduhan resmi"; isAllCaps = false; textSize = 16f
            setTextColor(white); setBackgroundColor(blue)
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(app.officialUrl))) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "Tidak dapat membuka tautan. Periksa browser dan koneksi internet.", Toast.LENGTH_LONG).show() }
            }
        }
        content.addView(download, matchWrap())
        val back = Button(this).apply { text = "Kembali ke katalog"; isAllCaps = false; setOnClickListener { renderHome() } }
        content.addView(back, matchWrap())
    }

    private fun label(text: String, color: Int, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; setTextColor(color); textSize = size
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
